Shelldon Terminal Bundle
========================

What this does
--------------
This installs your Shelldon-flavored terminal setup:
- turtle prompt for normal shells
- hare prompt + root tint for elevated shells
- desktop launcher + icon wiring
- sanity check command: `shelldon doctor`
- privileged entrypoint: `unleashShell`

Install
-------
From inside this folder:

  ./install-shelldon.sh

You will be asked for sudo for package installation.
If you are not asked for sudo, either everything is already installed
or your machine has achieved enlightenment.

Use It
------
- Normal launch:
  shelldon

- Health check:
  shelldon doctor

- Enter root shell in Shelldon mode:
  unleashShell

Legacy alias still works:
  suroot

Notes
-----
- Root's default login shell is NOT changed.
- `unleashShell` explicitly starts root zsh with your Shelldon config.
- This is deliberate: less surprise, less breakage, fewer "why is root weird" moments.

Rollback (if someone gets dramatic)
-----------------------------------
Remove user-level Shelldon artifacts:

  rm -f ~/.local/share/applications/shelldon.desktop
  rm -f ~/.local/share/icons/hicolor/16x16/apps/shelldon.png
  rm -f ~/.local/share/icons/hicolor/22x22/apps/shelldon.png
  rm -f ~/.local/share/icons/hicolor/24x24/apps/shelldon.png
  rm -f ~/.local/share/icons/hicolor/32x32/apps/shelldon.png
  rm -f ~/.local/share/icons/hicolor/48x48/apps/shelldon.png
  rm -f ~/bin/shelldon
  rm -rf ~/.zsh/shelldon
  update-desktop-database ~/.local/share/applications || true
  kbuildsycoca6 --noincremental || kbuildsycoca5 --noincremental || true

Then restore your preferred `~/.zshrc`.

Warranty
--------
No warranty is expressed or implied.
Side effects may include:
- coworkers grinning at prompts
- unexplained urge to customize keybinds
- elevated confidence while typing `ls`
