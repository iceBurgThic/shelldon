export PATH="$HOME/bin:/usr/local/bin:$PATH"
export LESS='-RFX'

export VISUAL='nano'
export EDITOR='nano'
