SHELLDON_BG_NORMAL="${SHELLDON_BG_NORMAL:-#1e1e2e}"
SHELLDON_BG_ROOT="${SHELLDON_BG_ROOT:-#5a2a2a}"

shelldon_set_bg() {
    [[ -t 1 ]] || return 0
    [[ -n "${TERM:-}" && "${TERM:-}" != "dumb" ]] || return 0
    printf "\033]11;%s\007" "$1"
}

shelldon_restore_bg() {
    shelldon_set_bg "$SHELLDON_BG_NORMAL"
}

if [[ $EUID -eq 0 ]]; then
    shelldon_set_bg "$SHELLDON_BG_ROOT"
    autoload -Uz add-zsh-hook
    add-zsh-hook zshexit shelldon_restore_bg
fi

ssh() {
    printf "\033]11;#9b0853\007"
    command ssh "$@"
    printf "\033]11;#1e1e2e\007"
}

unleashShell() {
    sudo env HOME="$HOME" ZDOTDIR="$HOME" /usr/bin/zsh -il
}

suroot() {
    unleashShell "$@"
}
