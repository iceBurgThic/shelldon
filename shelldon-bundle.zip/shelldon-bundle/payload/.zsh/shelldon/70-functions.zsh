ssh() {
    printf "\033]11;#9b0853\007"
    command ssh "$@"
    printf "\033]11;#1e1e2e\007"
}
