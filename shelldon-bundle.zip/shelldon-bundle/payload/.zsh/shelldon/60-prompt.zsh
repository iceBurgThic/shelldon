export PURE_PROMPT_SYMBOL='🐢'
export PURE_CMD_MAX_EXEC_TIME=5

RPROMPT='%(?.%F{green}✔%f.%F{red}✘%f)'
